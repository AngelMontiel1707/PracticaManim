from manim import *

from manim import *

class WarpSquare(Scene):
    def construct(self):
        square = Square(color=RED)
        square.set_fill(BLUE, opacity=0.5)
        self.play(
            ApplyPointwiseFunction(
                lambda point: complex_to_R3(np.exp(R3_to_complex(point))), square
            )
        )
        fadeOutSquare = FadeOut(square) # Animación de desaparición
        self.play(fadeOutSquare) # Mostrar la animación