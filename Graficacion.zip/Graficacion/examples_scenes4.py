from manim import *

class UpdatersExample(Scene):
    def construct(self):
        decimal = DecimalNumber(
            0,
            show_ellipsis=True,
            num_decimal_places=3,
            include_sign=True,
        )
        square = Square(color=BLUE).to_edge(UP)
        square.set_fill(RED, opacity=0.5)
        decimal.add_updater(lambda d: d.next_to(square, RIGHT))
        decimal.add_updater(lambda d: d.set_value(square.get_center()[1]))
        self.add(square, decimal)
        self.play(
            square.animate.to_edge(DOWN),  # Usamos .animate
            rate_func=there_and_back,
            run_time=5,
            
        )
        self.wait()
